aic=function(object,...){
  AIC=object$AIC
  return(AIC)
}

bic=function(object,...){
  BIC=object$BIC
  return(BIC)
}

JRRS=function(object,...){
  JRRS=object$JRRS
  return(JRRS)
}


